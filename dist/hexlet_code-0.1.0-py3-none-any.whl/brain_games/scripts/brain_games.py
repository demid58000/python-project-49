#!/usr/bin/env python3
from brain_games.cli import *
from brain_games.scripts.brain_even import is_even

def main():
   return 'Welcome to the Brain Games!'
print(main())

print(is_even())

