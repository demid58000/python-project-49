from brain_games.game_engine import game_run
from brain_games.games import brain_calc


def main():
    game_run(brain_calc)


if __name__ == "__main__":
    main()
