#!/usr/bin/env python3

def main():
  return 'Welcome to the Brain Games!'

print(main())



