### Hexlet tests and linter status:
[![Actions Status](https://github.com/demid58000/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/demid58000/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/e966b94f8276eca0e6d0/maintainability)](https://codeclimate.com/github/demid58000/python-project-49/maintainability)

Install and first run:

[![asciicast](https://asciinema.org/a/dtq8W7p4G87lWAjqhZ03YBGnQ.svg)](https://asciinema.org/a/dtq8W7p4G87lWAjqhZ03YBGnQ)

Brain-prime:

[![asciicast](https://asciinema.org/a/kCb516roDRAfkdil3LsbWVLkG.svg)](https://asciinema.org/a/kCb516roDRAfkdil3LsbWVLkG)

Brain progression:

[![asciicast](https://asciinema.org/a/1mjBrXzIfwOJlb8Q6XI4een9E.svg)](https://asciinema.org/a/1mjBrXzIfwOJlb8Q6XI4een9E)

Find greatest common divisor:

[![asciicast](https://asciinema.org/a/z8rn0daa1xlGOvr12udT3qERi.svg)](https://asciinema.org/a/z8rn0daa1xlGOvr12udT3qERi)

Brain calculator:

[![asciicast](https://asciinema.org/a/SpYMDSijvq560BQP5hMWSwqJ0.svg)](https://asciinema.org/a/SpYMDSijvq560BQP5hMWSwqJ0)

Brain even:

[![asciicast](https://asciinema.org/a/aUsw4wmL1MecYoRWlBIFnR4pk.svg)](https://asciinema.org/a/aUsw4wmL1MecYoRWlBIFnR4pk)