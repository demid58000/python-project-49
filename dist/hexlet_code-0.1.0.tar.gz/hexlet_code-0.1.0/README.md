### Hexlet tests and linter status:
[![Actions Status](https://github.com/demid58000/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/demid58000/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/e966b94f8276eca0e6d0/maintainability)](https://codeclimate.com/github/demid58000/python-project-49/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/e966b94f8276eca0e6d0/test_coverage)](https://codeclimate.com/github/demid58000/python-project-49/test_coverage)

[![asciicast](https://asciinema.org/a/kCb516roDRAfkdil3LsbWVLkG.svg)](https://asciinema.org/a/kCb516roDRAfkdil3LsbWVLkG)