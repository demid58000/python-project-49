### Hexlet tests and linter status:
[![Actions Status](https://github.com/demid58000/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/demid58000/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/e966b94f8276eca0e6d0/maintainability)](https://codeclimate.com/github/demid58000/python-project-49/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/e966b94f8276eca0e6d0/test_coverage)](https://codeclimate.com/github/demid58000/python-project-49/test_coverage)

https://asciinema.org/connect/ebc9cc63-1042-4c3b-b78d-711c779d3dc1