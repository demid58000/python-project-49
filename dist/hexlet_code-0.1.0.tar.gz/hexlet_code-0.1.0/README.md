### Hexlet tests and linter status:
[![Actions Status](https://github.com/demid58000/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/demid58000/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/e966b94f8276eca0e6d0/maintainability)](https://codeclimate.com/github/demid58000/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/kCb516roDRAfkdil3LsbWVLkG.svg)](https://asciinema.org/a/kCb516roDRAfkdil3LsbWVLkG)

[![asciicast](https://asciinema.org/a/1mjBrXzIfwOJlb8Q6XI4een9E.svg)](https://asciinema.org/a/1mjBrXzIfwOJlb8Q6XI4een9E)

[![asciicast](https://asciinema.org/a/z8rn0daa1xlGOvr12udT3qERi.svg)](https://asciinema.org/a/z8rn0daa1xlGOvr12udT3qERi)

[![asciicast](https://asciinema.org/a/SpYMDSijvq560BQP5hMWSwqJ0.svg)](https://asciinema.org/a/SpYMDSijvq560BQP5hMWSwqJ0)

[![asciicast](https://asciinema.org/a/aUsw4wmL1MecYoRWlBIFnR4pk.svg)](https://asciinema.org/a/aUsw4wmL1MecYoRWlBIFnR4pk)