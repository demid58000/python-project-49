# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/demid58000/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/demid58000/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/e966b94f8276eca0e6d0/maintainability)](https://codeclimate.com/github/demid58000/python-project-49/maintainability)\n\nInstall and first run:\n\n[![asciicast](https://asciinema.org/a/dtq8W7p4G87lWAjqhZ03YBGnQ.svg)](https://asciinema.org/a/dtq8W7p4G87lWAjqhZ03YBGnQ)\n\nBrain-prime:\n\n[![asciicast](https://asciinema.org/a/kCb516roDRAfkdil3LsbWVLkG.svg)](https://asciinema.org/a/kCb516roDRAfkdil3LsbWVLkG)\n\nBrain progression:\n\n[![asciicast](https://asciinema.org/a/1mjBrXzIfwOJlb8Q6XI4een9E.svg)](https://asciinema.org/a/1mjBrXzIfwOJlb8Q6XI4een9E)\n\nFind greatest common divisor:\n\n[![asciicast](https://asciinema.org/a/z8rn0daa1xlGOvr12udT3qERi.svg)](https://asciinema.org/a/z8rn0daa1xlGOvr12udT3qERi)\n\nBrain calculator:\n\n[![asciicast](https://asciinema.org/a/SpYMDSijvq560BQP5hMWSwqJ0.svg)](https://asciinema.org/a/SpYMDSijvq560BQP5hMWSwqJ0)\n\nBrain even:\n\n[![asciicast](https://asciinema.org/a/aUsw4wmL1MecYoRWlBIFnR4pk.svg)](https://asciinema.org/a/aUsw4wmL1MecYoRWlBIFnR4pk)',
    'author': 'Dmitry Shahov',
    'author_email': 'demid58000@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/demid58000/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
